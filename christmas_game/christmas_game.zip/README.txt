Hello, menus are hard to make.
This is a quick run down of the game

Shoot the baachis with presents! 
The controls are the following:
Left arrow: move left
Right arrow: move right
Z key: Shoot red present
X key: Shoot green present
C key: Shoot blue present

You get more points for shooting
the baachis that have matching
sweater colors with the same color
present!

If the mystical totem essie appears,
shoot her with anything to get more time!

Get as high of a score as you can before
the timer runs out!

Also Merry Christmas!